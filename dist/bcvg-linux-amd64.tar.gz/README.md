# bilibili-comments-viewer-go
一个简单的B站评论爬虫
